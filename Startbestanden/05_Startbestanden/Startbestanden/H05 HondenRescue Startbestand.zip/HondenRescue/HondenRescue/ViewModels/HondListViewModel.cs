﻿using HondenRescue.Models;

namespace HondenRescue.ViewModels
{
    public class HondListViewModel
    {
        public List<Hond> Honden { get; set; } = default!;
    }
}
